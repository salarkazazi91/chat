import { Component, OnInit } from '@angular/core';
import {   faVoteYea } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-chatroom',
  templateUrl: './chatroom.component.html',
  styleUrls: ['./chatroom.component.scss']
})
export class ChatroomComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  wheel =faVoteYea;

}
