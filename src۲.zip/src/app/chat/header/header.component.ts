import { Component, OnInit } from '@angular/core';
import { faBell, faQuestion, faVoteYea } from '@fortawesome/free-solid-svg-icons';
import { faElementor } from '@fortawesome/free-brands-svg-icons';
import { faChartBar } from '@fortawesome/free-regular-svg-icons';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  icon = faElementor;
  bell = faBell;
  wheel = faVoteYea;
  question_mark = faQuestion;
  imagePath = "/assets/";
  bizImagePath = this.imagePath + "bizlogo.jpg";
  userImagePath = this.imagePath + "unnamed.jpg";
}
