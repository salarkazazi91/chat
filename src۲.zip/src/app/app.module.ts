import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { RouterModule, Routes } from '@angular/router';


import { AppComponent } from './app.component';
import { ChatComponent } from './chat/chat.component';
import { HeaderComponent } from './chat/header/header.component';
import { MainComponent } from './chat/main/main.component';
 
import { CommonModule } from '@angular/common';

import { FontAwesomeModule, FaIconLibrary } from '@fortawesome/angular-fontawesome';
import { faSquare, faCheckSquare, faBars } from '@fortawesome/free-solid-svg-icons';
import { faSquare as farSquare, faCheckSquare as farCheckSquare } from '@fortawesome/free-regular-svg-icons';
import { faStackOverflow, faGithub, faMedium } from '@fortawesome/free-brands-svg-icons';
import { SidebarComponent } from './chat/main/sidebar/sidebar.component';
import { UsersComponent } from './chat/main/users/users.component';
import { ChatroomComponent } from './chat/main/chatroom/chatroom.component';

const routes: Routes = [
  { path: '', component: ChatComponent }
]

@NgModule({
  declarations: [
    AppComponent,
    ChatComponent,
    HeaderComponent,
    MainComponent,
    SidebarComponent,
    UsersComponent,
    ChatroomComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes), FontAwesomeModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor(private library: FaIconLibrary) {
    library.addIcons(faBars);
  }
}
