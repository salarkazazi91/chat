import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { HeaderComponent } from './chat/header/header.component';
import { NavSideComponent } from './chat/nav-side/nav-side.component';
import { UserListComponent } from './chat/user-list/user-list.component';
import { ChatroomComponent } from './chat/chatroom/chatroom.component';
import { FooterComponent } from './chat/footer/footer.component';
import { ChatComponent } from './chat/chat.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    NavSideComponent,
    UserListComponent,
    ChatroomComponent,
    FooterComponent,
    ChatComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
